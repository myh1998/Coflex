
import numpy as np
import torchvision
import torchvision.transforms as transforms
import numexpr as ne
import torch
from scipy import stats
import random
from torchvision.datasets import ImageFolder

from models import get_cell_based_tiny_net
from nats_bench import create

 
def normalize(x, axis=None):
    x_min = x.min(axis=axis, keepdims=True)
    x_max = x.max(axis=axis, keepdims=True)
    x_max[x_max == x_min] = 1
    x_min[x_max == x_min] = 0
    return (x - x_min) / (x_max - x_min)

def main():
  # Reproducibility
  print('==> Reproducibility..')
  torch.backends.cudnn.deterministic = True
  torch.backends.cudnn.benchmark = False
  np.random.seed(1)
  torch.manual_seed(1)

  # GPU
  # Check that CUDA is available
  # device = 'cuda' if torch.cuda.is_available() else 'cpu'
  # Check that MPS is available
  if not torch.backends.mps.is_available():
    device = 'cpu'
  else:
    device = 'mps'  # use cpu
  print('device GPU: ', device)
      

  # Hyperparameter
  print('==> Preparing hyperparameters..')
  batch_size_NE = 8
  Num_Networks = 32768
  maxtrials = 1
  N_GAMMA = 10

  # Image Data
  print('==> Preparing data..')
  img_root = "/Users/tomomasayamasaki/Library/CloudStorage/OneDrive-SingaporeUniversityofTechnologyandDesign/SUTD/Life_of_University/Lab/#5Research-FRCNSim/Program/Dataset/ILSVRC2012_img_val_for_ImageFolder"
  benchmark_root = "/Users/tomomasayamasaki/Library/CloudStorage/OneDrive-SingaporeUniversityofTechnologyandDesign/SUTD/Life_of_University/Lab/#4Research-RBFleX/nds_data"
  norma = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                    std=[0.229, 0.224, 0.225])

  train_transform = transforms.Compose([
      transforms.RandomResizedCrop(224), 
      transforms.ToTensor(),
      norma,
  ])
  imgset = ImageFolder(root=img_root,
                      transform=train_transform)
  img_loader = torch.utils.data.DataLoader(
      imgset, batch_size=batch_size_NE, shuffle=True, num_workers=2, pin_memory=True)
  data_iterator = iter(img_loader)
  x, target = next(data_iterator)

  # NAS Benchmark
  api_loc = '/Users/tomomasayamasaki/Library/CloudStorage/OneDrive-SingaporeUniversityofTechnologyandDesign/SUTD/Life_of_University/Lab/#5Research-FRCNSim/Program/NATS-Bench/NATS-sss-v1_0-50262-simple'
  print('Loading...NAT Bench SSS')
  searchspace = create(api_loc, 'sss', fast_mode=True, verbose=False)


    

  # Model
  print('==> Building model..')
  pearson_array = np.zeros(maxtrials)
  kendall_array = np.zeros(maxtrials)
  accracy_array = np.zeros(maxtrials)
  rd_pearson_array = np.zeros(maxtrials)
  rd_kendall_array = np.zeros(maxtrials)
  rd_accracy_array = np.zeros(maxtrials)
  for r in range(maxtrials):
    

    score18_array = np.zeros(Num_Networks)
    acc_array = np.zeros(Num_Networks)
    uid_array = np.zeros(Num_Networks)
    
    ########################
    # Compute Distance and Kernel Matrix
    ########################
    def counting_forward_hook(module, inp, out):
        arr = out.view(-1)
        network.K = torch.concatenate([network.K, arr])
        
    def counting_forward_hook_FC(module, inp, out):
        arr = inp[0].view(-1)
        network.Q = torch.concatenate([network.Q, arr])
    
    # Detect hyperparameter GAMMA
    GAMMA_K_list = []
    GAMMA_Q_list = []
    batch_space = random.sample(range(len(searchspace)), N_GAMMA)
    for id in range(N_GAMMA):
      uid = batch_space[id]
      config = searchspace.get_net_config(uid, 'ImageNet16-120')
      network = get_cell_based_tiny_net(config)
      network = network.to(device)

      
      
      net_counter = list(network.named_modules())
      net_counter = len(net_counter)
      NC = 0
      for name, module in network.named_modules():
        NC += 1
        if 'ReLU' in str(type(module)):
          module.register_forward_hook(counting_forward_hook)
        if NC == net_counter:
          module.register_forward_hook(counting_forward_hook_FC)
          
      # Check LA
      x2 = torch.clone(x[0:1,:,:,:])
      x2 = x2.to(device)
      network.K = torch.tensor([], device=device)
      network.Q = torch.tensor([], device=device)
      network(x2)
      LA = len(network.K)
      LAQ = len(network.Q)
      
      Output_matrix = np.zeros([batch_size_NE, LA])
      Last_matrix = np.zeros([batch_size_NE, LAQ])
      for i in range(batch_size_NE):
        x2 = torch.clone(x[i:i+1,:,:,:])
        x2 = x2.to(device)
        network.K = torch.tensor([], device=device)
        network.Q = torch.tensor([], device=device)
        network(x2)
        Output_matrix[i,:] = network.K.cpu().detach().clone().numpy()
        Last_matrix[i,:] = network.Q.cpu().detach().clone().numpy()
        
      for i in range(batch_size_NE-1):
        for j in range(i+1,batch_size_NE):
            z1 = Output_matrix[i,:]
            z2 = Output_matrix[j,:]
            m1 = np.mean(z1)
            m2 = np.mean(z2)
            M = (m1-m2)**2
            z1 = z1-m1
            z2 = z2-m2
            s1 = np.mean(z1**2)
            s2 = np.mean(z2**2)
            if s1+s2 != 0:
              candi_gamma_K = M/((s1+s2)*2)
              GAMMA_K_list.append(candi_gamma_K)
              
      for i in range(batch_size_NE-1):
        for j in range(i+1,batch_size_NE):
            z1 = Last_matrix[i,:]
            z2 = Last_matrix[j,:]
            m1 = np.mean(z1)
            m2 = np.mean(z2)
            M = (m1-m2)**2
            z1 = z1-m1
            z2 = z2-m2
            s1 = np.mean(z1**2)
            s2 = np.mean(z2**2)
            if s1+s2 != 0:
              candi_gamma_Q = M/((s1+s2)*2)
              GAMMA_Q_list.append(candi_gamma_Q)
            
    GAMMA_K = np.min(np.array(GAMMA_K_list))
    GAMMA_Q = np.min(np.array(GAMMA_Q_list))
    print("======================================")
    print('Trial: ', r+1)
    # print()
    print('gamma_k:',GAMMA_K)
    print('gamma_q:',GAMMA_Q)
    
    # compute score
    batch_space = list(range(0, Num_Networks))
    for numbers, uid in enumerate(batch_space):
      config = searchspace.get_net_config(uid, 'ImageNet16-120')
      network = get_cell_based_tiny_net(config)
      network = network.to(device)
      
          
      net_counter = list(network.named_modules())
      net_counter = len(net_counter)
      NC = 0
      for name, module in network.named_modules():
        NC += 1
        if 'ReLU' in str(type(module)):
          module.register_forward_hook(counting_forward_hook)
        if NC == net_counter:
          module.register_forward_hook(counting_forward_hook_FC)
      
      #ls
      #print('NFC:',NFC)
      # Check LA
      x2 = torch.clone(x[0:1,:,:,:])
      x2 = x2.to(device)
      network.K = torch.tensor([], device=device)
      network.Q = torch.tensor([], device=device)
      network(x2)
      LA = len(network.K)
      LAQ = len(network.Q)
      
      Output_matrix = np.zeros([batch_size_NE, LA])
      Last_matrix = np.zeros([batch_size_NE, LAQ])
      for i in range(batch_size_NE):
        x2 = torch.clone(x[i:i+1,:,:,:])
        x2 = x2.to(device)
        network.K = torch.tensor([], device=device)
        network.Q = torch.tensor([], device=device)
        network(x2)
        Output_matrix[i,:] = network.K.cpu().detach().clone().numpy()
        Last_matrix[i,:] = network.Q.cpu().detach().clone().numpy()
        
      # Normalization
      Output_matrix = normalize(Output_matrix, axis=0)
      Last_matrix = normalize(Last_matrix, axis=0)
      
      # RBF kernel
      X_norm = np.sum(Output_matrix ** 2, axis = -1)
      K_Matrix = ne.evaluate('exp(-g * (A + B - 2 * C))', {
              'A' : X_norm[:,None],
              'B' : X_norm[None,:],
              'C' : np.dot(Output_matrix, Output_matrix.T),
              'g' : GAMMA_K
      })
      Y_norm = np.sum(Last_matrix ** 2, axis = -1)
      Q_Matrix = ne.evaluate('exp(-g * (A + B - 2 * C))', {
              'A' : Y_norm[:,None],
              'B' : Y_norm[None,:],
              'C' : np.dot(Last_matrix, Last_matrix.T),
              'g' : GAMMA_Q
      })
      

      _, score_id18 = np.linalg.slogdet(np.kron(K_Matrix, Q_Matrix)) # idea18
      accuracy, latency, time_cost, current_total_time_cost = searchspace.simulate_train_eval(uid, dataset='ImageNet16-120')
      if numbers%10 == 9:
        print('No. {}'.format(numbers+1))
      if np.isinf(score_id18):
        score_id18 = -1e10
        
      score18_array[numbers] = score_id18
      acc_array[numbers] = accuracy
      uid_array[numbers] = uid

      if numbers % 100 == 99:
        np.savetxt('./Result/Result_Score_SSS-'+str(numbers)+'.csv', score18_array)
        np.savetxt('./Result/Result_Acc_SSS-'+str(numbers)+'.csv', acc_array)
        np.savetxt('./Result/Result_Uid_SSS-'+str(numbers)+'.csv', uid_array)
      
      
    CC_18 = np.corrcoef(acc_array, score18_array)
    tau18, p = stats.kendalltau(acc_array,score18_array)
    top_score = np.amax(score18_array)
    top_idx = np.where(score18_array == np.amax(score18_array))
    if len(top_idx[0]) > 1:
      better_accuracy = 0
      for idx in top_idx[0]:
        if acc_array[idx] > better_accuracy:
          better_accuracy = acc_array[idx]
    else:
      better_accuracy = acc_array[top_idx]
    
    print('pearson: ',CC_18[0,1])
    print('kendall: ', tau18)
    print('top score: ', top_score)
    print('top accuracy: ', better_accuracy)
    #np.savetxt('NDS['+space_name+']_RBFleX_TR['+str(r)+'].csv', score18_array)
    #np.savetxt('Accuracy_TR['+str(r)+'].csv', acc_array)
    pearson_array[r] = CC_18[0,1]
    kendall_array[r] = tau18
    accracy_array[r] = better_accuracy[0]
    
    rand_idx = np.random.randint(0, Num_Networks-1)
    rd_accracy_array[r] = acc_array[rand_idx]

  
    # print()
    print('====== SUMMARY (RBFleX) ======')
    print('Device: ', device)
    print('Num of networks: ', len(searchspace))
    print('mean Pearson: ', np.mean(pearson_array))
    print('mean Kendall: ', np.mean(kendall_array))
    print('mean final accuracy: ', np.mean(accracy_array))
    print('top network index: ', uid_array[top_idx])
    
    #print()
    #print('====== SUMMARY (Random) ======')
    #print('mean final accuracy (random): ', np.mean(rd_accracy_array))
    #print('top network index (random): ', uid_array[rand_idx])
    #print('top network acc. (random): ', searchspace.get_final_accuracy(int(uid_array[rand_idx][0])))

    np.savetxt('./Result/Result_Score_SSS-full.csv', score18_array)
    np.savetxt('./Result/Result_Acc_SSS-full.csv', acc_array)
    np.savetxt('./Result/Result_Uid_SSS-full.csv', uid_array)

    




if __name__ == '__main__':
  main()


