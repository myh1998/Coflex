
import numpy as np
import torchvision
import torchvision.transforms as transforms
import numexpr as ne
import torch
from scipy import stats
import random
from torchvision.datasets import ImageFolder

from models import get_cell_based_tiny_net
from nats_bench import create


def get_acc(arch):
  api_loc = 'D:/COFleX/COFleX/NATS-sss-v1_0-50262-simple'
  searchspace = create(api_loc, 'sss', fast_mode=True, verbose=False)

  uid = searchspace.query_index_by_arch(arch)
  accuracy, latency, time_cost, current_total_time_cost = searchspace.simulate_train_eval(uid, dataset='ImageNet16-120', hp='90')
  return accuracy

 

def main():
  
  if not torch.backends.mps.is_available():
    device = 'cpu'
  else:
    device = 'mps'  # use cpu
  print('device GPU: ', device)
      

  # Hyperparameter
  
  

  # NAS Benchmark
  api_loc = '/Users/tomomasayamasaki/Library/CloudStorage/OneDrive-SingaporeUniversityofTechnologyandDesign/SUTD/Life_of_University/Lab/#5Research-FRCNSim/Program/NATS-Bench/NATS-sss-v1_0-50262-simple'
  print('Loading...NAT Bench SSS')
  searchspace = create(api_loc, 'sss', fast_mode=True, verbose=False)

  arch = '{}:{}:{}:{}:{}'.format(64,48,64,48,64)
  uid = searchspace.query_index_by_arch(arch)
  accuracy, latency, time_cost, current_total_time_cost = searchspace.simulate_train_eval(uid, dataset='ImageNet16-120', hp='90')
  print('uid: ', uid)
  print('arch: ', arch)
  print('accuracy', accuracy)


if __name__ == '__main__':
  main()


