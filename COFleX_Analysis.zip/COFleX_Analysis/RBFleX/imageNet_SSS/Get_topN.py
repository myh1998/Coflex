import pandas as pd

Top_N = 5

uid_array = pd.read_csv('./Result/Result_Uid_SSS-full.csv', header=None, names=["uid"])
score18_array = pd.read_csv('./Result/Result_Score_SSS-full.csv', header=None, names=["score"])
acc_array = pd.read_csv('./Result/Result_Acc_SSS-full.csv', header=None, names=["acc"])
print(uid_array)

df = pd.concat([uid_array, score18_array, acc_array], axis=1)
df_sort = df.sort_values("score", ascending=False)


print(df_sort[0:Top_N])